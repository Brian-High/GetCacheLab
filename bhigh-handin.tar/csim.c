#include "cachelab.h"
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <stdbool.h>
#include <math.h>

/*************************************************************
*
*         Brian High
*         bhigh@unm.edu
*/

struct cacheLine{
    int validBit;
    long tagBits;
    int lineAge;
};

struct cacheSet{
    struct cacheLine *lines; //array of the lines in the set
};

int numHits = 0; 
int numMisses = 0;
int numEvictions = 0;

void loadCache(int E, struct cacheSet currSet, bool verbose, long tag);
void initCache(int E, int S, struct cacheSet *cache);

int main(int argc, char *argv[]) {
    int S;
    int s = -1;
    int E = -1;
    int b = -1;
    char* tracefile = NULL;
    bool verbose = false;
    
    //Parse command line inputs
    int arg;
    int argCount = 0;
    while ((arg = getopt(argc, argv, "hvs:E:b:t:")) != -1) {
        switch (arg) {
            case 'h':
		printf("Usage: %s [-h] [-v] -s <num> -E <num> -b <num> -t <file>\n", argv[0]);
                printf("\t-h: Optional help flag that prints usage info\n");
                printf("\t-v: Optional verbose flag that displays trace info\n");
                printf("\t-s <num>: Number of set index bits (S = 2^s is the number of sets)\n");
                printf("\t-E <num>: Associativity (number of lines per set)\n");
                printf("\t-b <num>: Number of block bits (B = 2^b is the block size)\n");
                printf("\t-t <file>: Name of the valgrind trace to replay\n");
                exit(0);
            case 'v':
                verbose = true;
                break;
            case 's':
                s = atoi(optarg);
                argCount++;
		break;
            case 'E':
                E = atoi(optarg);
                argCount++;
                break;
            case 'b':
                b = atoi(optarg);
                argCount++;
                break;
            case 't':
                tracefile = optarg;
                argCount++;
                break;
            default:
        	exit(1);
	}
    }

    if(argCount != 4){
	printf("command line argument error");
	exit(1);
    }

    S = pow(2,s);

    //initialize the cache
    struct cacheSet cache[S];
    initCache(E, S, cache);

    //Parse Trace File
    FILE* fp = fopen(tracefile, "r");
    char line[100];

    char command;
    char addressHex[10];
    int size;
    int address;


    while (fgets(line, sizeof(line), fp)) {
        sscanf(line, " %c %[^,],%d", &command, addressHex, &size);
        address = (int)strtol(addressHex, NULL, 16);
	
	if(verbose) printf("%c,%d,%d ",command,address,size);

        unsigned int setIndex = (address >> b) & ((1 << s) - 1);
	unsigned long tag = address >> (s + b);
	
	//Execute Commands
	struct cacheSet currSet = cache[setIndex];
	switch (command) {
            case 'L':
		    loadCache(E,currSet,verbose,tag);
		break;
	    case 'S':
		    loadCache(E,currSet,verbose,tag);
		break;
	    case 'M':
		    loadCache(E,currSet,verbose,tag);
		    loadCache(E,currSet,verbose,tag);
		break;
	}
	if(verbose) printf("\n");
    }
    fclose(fp);
    printSummary(numHits,numMisses,numEvictions);
    return 0;
}

//Used to load and store to the cache
void loadCache(int E, struct cacheSet currSet, bool verbose, long tag){
   int oldestInd;

   //Increase the age of all the lines in the set
   for (int i = 0; i < E; i++) currSet.lines[i].lineAge++; 

   //Check if Cache contains tag
   for (int i = 0; i < E; i++) {
       	    if (currSet.lines[i].validBit && currSet.lines[i].tagBits == tag) {
       		// Cache Hit
	        if(verbose) printf("hit ");
		numHits++;
               	currSet.lines[i].lineAge = 0;
             return;
        }
    }

    //Cache Miss
    if(verbose) printf("miss ");
    numMisses++;
    for (int i = 0; i < E; i++) {    
	if (!currSet.lines[i].validBit) {
	     currSet.lines[i].tagBits = tag;
	     currSet.lines[i].validBit = 1;
  	     currSet.lines[i].lineAge = 0;
             return; 
    	}
    }
		

    //Eviction
    if(verbose) printf("eviction ");
    for (int i = 0; i < E; i++) {
        if(currSet.lines[oldestInd].lineAge < currSet.lines[i].lineAge) oldestInd = i;
    }
    numEvictions++;
    currSet.lines[oldestInd].validBit = 1;
    currSet.lines[oldestInd].tagBits = tag;
    currSet.lines[oldestInd].lineAge = 0;
    return;
}

//initializes the cache sets and empty lines
void initCache(int E, int S, struct cacheSet *cache){
    
    for(int i = 0; i < S; i++){
        struct cacheSet set;
        set.lines = malloc(E * sizeof(struct cacheLine));
        cache[i] = set;

        for (int j = 0; j < E; j++) {
            set.lines[j].validBit = 0;
            set.lines[j].tagBits = 0;
            set.lines[j].lineAge = 0;
        }
    }
}

